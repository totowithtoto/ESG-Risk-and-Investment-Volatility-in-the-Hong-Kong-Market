import numpy as np
import pandas as pd
import yfinance as yf
import matplotlib.pyplot as plt
pd.set_option('display.max_columns', 50, 'display.width', 200)

df = pd.read_csv('Company information_update.csv')
df1 = df.groupby('Sector')["Ticker"].count().reset_index()
#print(df1)

df2 = df1.sort_values(by='Ticker', ascending=False)
#print(df2)

import seaborn as sns

# Set a color palette
# Light Green Color Codes
# Hex Code: #90EE90 (Light Green)
# Hex Code: #98FB98 (Pale Green)
# Hex Code: #B2FF66 (Light Lime Green)
# Hex Code: #AEEEEE (Pale Turquoise, which has a greenish tint)

pastel_colors = [
    '#FFB3BA',  # Light Pink
    '#FFDFBA',  # Light Peach
    '#FFFFBA',  # Light Yellow
    '#BAFFC9',  # Light Mint Green
    '#BAE1FF',  # Light Blue
    '#FFB3E6',  # Light Lavender
    '#FF9A8D',  # Soft Coral
    '#FFCCBA',  # Light Apricot
    '#D0E1F9',  # Soft Sky Blue
    '#D4C8E7',  # Light Lilac
    '#90EE90',  # Light Green
]

#colors = sns.color_palette('colorblind')  # Options include 'deep', 'muted', 'bright', 'pastel', 'dark', 'colorblind'

# colors = ['gold', 'yellowgreen', 'lightcoral', 'lightskyblue', 'pink',
#           'purple', 'orange', 'gray', 'brown', 'olive', 'cyan']

plt.pie(df2["Ticker"], labels=df2['Sector'], autopct='%1.2f%%', colors=pastel_colors,
        textprops={'fontsize': 12},  # Increase font size of labels and value labels
        pctdistance=0.8,  # Move percentage labels further out
        labeldistance=1.1)  # Move sector labels further out)

plt.title('Proportion of companies in each sector', fontsize=18)

plt.show()
