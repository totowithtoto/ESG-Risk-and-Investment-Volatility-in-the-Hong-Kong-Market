
import pandas as pd
import numpy as np

dr = pd.read_csv("Daily_Return.csv", index_col=0)
dr = dr.T

drupdate = dr.drop(["2007.HK", "3333.HK", "4332.HK", "4333.HK", "4335.HK", "4336.HK", "4337.HK", "4338.HK",], axis=1)
drupdate = drupdate.T
drupdate.to_csv("Daily_Return_Update.csv")
#print(drupdate)

sector = pd.read_csv("Company information_update.csv", index_col=0)
sector = pd.DataFrame(sector["Sector"])
#print(sector)

drsec = pd.merge(sector, drupdate, on="Ticker", how="left" )
drsec = drsec.set_index("Sector").T

print(drsec)

import seaborn as sns
import matplotlib.pyplot as plt

# Create the violin plot
plt.figure(figsize=(8, 6))
sns.violinplot(data=drsec, palette="Blues_d")
plt.xlabel('Sector')
plt.xticks(rotation=30, horizontalalignment='right')
plt.ylabel('Daily Return')
plt.title('Daily Return distribution by Sector')
plt.subplots_adjust(bottom=0.3)
plt.show()

