import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#import seaborn as sns
#import yfinance as yf
#from pandas.plotting import scatter_matrix
pd.set_option('display.max_columns', 50, 'display.width', 200)

df = pd.read_csv("Daily Return describe.csv")
df = df[["Ticker", "STD"]]
df1 = df.sort_values("STD").head(10)
df2 = df.sort_values("STD").tail(10)

# print("Smallest 10 STD", df1)
# print("Highest 10 STD", df2)

dr = pd.read_csv("Daily_Return.csv")
dr = dr.set_index("Ticker").T
dr2 = dr[["2638.HK", "6823.HK", "0945.HK", "0006.HK"]]  #Top 4 stable co. with smallest STD of Daily Return
dr1 = dr[["9901.HK", "0020.HK", "6808.HK", "0960.HK"]]  #Top 4 volatile co. with highest STD of Daily Return
#dr3 = dr.sort_values("0960.HK").head(240)
#print(dr)


#Visualize the results.
figure, axes = plt.subplots(2, 2, figsize = (15, 10))
figure.suptitle('Stability and Volatility for Top 4 Stable companies [Smallest STD]')

axes[0,0].set_title('2638.HK')
axes[0,1].set_title('6823.HK')
axes[1,0].set_title('0945.HK')
axes[1,1].set_title('0006.HK')

dr2['2638.HK'].hist(bins = 100, label = '2638.HK', alpha = 0.5, ax=axes[0, 0])
axes[0,0].set_xticks(np.arange(-0.06, 0.0601, 0.01))
axes[0,0].axvline(dr2['2638.HK'].median(), color='r', linestyle='dashed', linewidth=1)
axes[0,0].text(dr2['2638.HK'].median(), 0.99, "median:{:#.4g}".format(dr2['2638.HK'].median()), color='r', ha='right', va='top', rotation=0,
            transform=axes[0,0].get_xaxis_transform())
axes[0,0].text(dr2['2638.HK'].std(), 0.89, "std:{:#.4g}".format(dr2['2638.HK'].std()), color='g', ha='left', va='top', rotation=0,
            transform=axes[0,0].get_xaxis_transform())

dr2['6823.HK'].hist(bins = 100, label = '6823.HK', alpha = 0.5, ax=axes[0, 1])
axes[0,1].set_xticks(np.arange(-0.06, 0.0601, 0.01))
axes[0,1].axvline(dr2['6823.HK'].median(), color='r', linestyle='dashed', linewidth=1)
axes[0,1].text(dr2['6823.HK'].median(), 0.99, "median:{:#.4g}".format(dr2['6823.HK'].median()), color='r', ha='right', va='top', rotation=0,
            transform=axes[0,1].get_xaxis_transform())
axes[0,1].text(dr2['6823.HK'].std(), 0.89, "std:{:#.4g}".format(dr2['6823.HK'].std()), color='g', ha='left', va='top', rotation=0,
            transform=axes[0,1].get_xaxis_transform())

dr2['0945.HK'].hist(bins = 100, label = '0945.HK', alpha = 0.5, ax=axes[1, 0])
axes[1,0].set_xticks(np.arange(-0.06, 0.0601, 0.01))
axes[1,0].axvline(dr2['0945.HK'].median(), color='r', linestyle='dashed', linewidth=1)
axes[1,0].text(dr2['0945.HK'].median(), 0.99, "median:{:#.8g}".format(dr2['0945.HK'].median()), color='r', ha='right', va='top', rotation=0,
            transform=axes[1,0].get_xaxis_transform())
axes[1,0].text(dr2['0945.HK'].std(), 0.89, "std:{:#.4g}".format(dr2['0945.HK'].std()), color='g', ha='left', va='top', rotation=0,
            transform=axes[1,0].get_xaxis_transform())

dr2['0006.HK'].hist(bins = 100, label = '0006.HK', alpha = 0.5, ax=axes[1, 1])
axes[1,1].set_xticks(np.arange(-0.06, 0.0601, 0.01))
axes[1,1].axvline(dr2['0006.HK'].median(), color='r', linestyle='dashed', linewidth=1)
axes[1,1].text(dr2['0006.HK'].median(), 0.99, "median:{:#.4g}".format(dr2['0006.HK'].median()), color='r', ha='right', va='top', rotation=0,
            transform=axes[1,1].get_xaxis_transform())
axes[1,1].text(dr2['0006.HK'].std(), 0.89, "std:{:#.4g}".format(dr2['0006.HK'].std()), color='g', ha='left', va='top', rotation=0,
            transform=axes[1,1].get_xaxis_transform())


figure, axes = plt.subplots(2, 2, figsize = (15, 10))
figure.suptitle('Stability and Volatility for Top 4 Volatile companies [Highest STD]')

axes[0,0].set_title('9901.HK')
axes[0,1].set_title('0020.HK')
axes[1,0].set_title('6808.HK')
axes[1,1].set_title('0960.HK')

dr1['9901.HK'].hist(bins = 100, label = '9901.HK', alpha = 0.5, ax=axes[0, 0])
axes[0,0].axvline(dr1['9901.HK'].median(), color='r', linestyle='dashed', linewidth=1)
axes[0,0].text(dr1['9901.HK'].median(), 0.99, "median:{:#.4g}".format(dr1['9901.HK'].median()), color='r', ha='right', va='top', rotation=0,
            transform=axes[0,0].get_xaxis_transform())
axes[0,0].text(dr1['9901.HK'].std(), 0.89, "std:{:#.4g}".format(dr1['9901.HK'].std()), color='g', ha='left', va='top', rotation=0,
            transform=axes[0,0].get_xaxis_transform())

dr1['0020.HK'].hist(bins = 100, label = '0020.HK', alpha = 0.5, ax=axes[0, 1])
axes[0,1].axvline(dr1['0020.HK'].median(), color='r', linestyle='dashed', linewidth=1)
axes[0,1].text(dr1['0020.HK'].median(), 0.99, "median:{:#.4g}".format(dr1['0020.HK'].median()), color='r', ha='right', va='top', rotation=0,
            transform=axes[0,1].get_xaxis_transform())
axes[0,1].text(dr1['0020.HK'].std(), 0.89, "std:{:#.4g}".format(dr1['0020.HK'].std()), color='g', ha='left', va='top', rotation=0,
            transform=axes[0,1].get_xaxis_transform())

dr1['6808.HK'].hist(bins = 100, label = '6808.HK', alpha = 0.5, ax=axes[1, 0])
axes[1,0].axvline(dr1['6808.HK'].median(), color='r', linestyle='dashed', linewidth=1)
axes[1,0].text(dr1['6808.HK'].median(), 0.99, "median:{:#.8g}".format(dr1['6808.HK'].median()), color='r', ha='right', va='top', rotation=0,
            transform=axes[1,0].get_xaxis_transform())
axes[1,0].text(dr1['6808.HK'].std(), 0.89, "std:{:#.4g}".format(dr1['6808.HK'].std()), color='g', ha='left', va='top', rotation=0,
            transform=axes[1,0].get_xaxis_transform())

dr1['0960.HK'].hist(bins = 100, label = '0960.HK', alpha = 0.5, ax=axes[1, 1])
axes[1,1].axvline(dr1['0960.HK'].median(), color='r', linestyle='dashed', linewidth=1)
axes[1,1].text(dr1['0960.HK'].median(), 0.99, "median:{:#.4g}".format(dr1['0960.HK'].median()), color='r', ha='right', va='top', rotation=0,
            transform=axes[1,1].get_xaxis_transform())
axes[1,1].text(dr1['0960.HK'].std(), 0.89, "std:{:#.4g}".format(dr1['0960.HK'].std()), color='g', ha='left', va='top', rotation=0,
            transform=axes[1,1].get_xaxis_transform())

custom_xlim = (-0.25, 0.2501)
plt.setp(axes, xlim=custom_xlim)


figure, axes = plt.subplots(1, 1, figsize = (10, 7))
figure.suptitle('Stability and Volatility for Top Stable & Volatile companies [Highest/ Smallest STD]')
dr2['2638.HK'].hist(bins = 30, label = '2638.HK', alpha = 0.5, figsize = (10,7))
axes.axvline(dr2['2638.HK'].median(), color='b', linestyle='dashed', linewidth=1)
axes.text(dr2['2638.HK'].median(), 0.99, "2638.HK median:{:#.4g}".format(dr2['2638.HK'].median()), color='b', ha='right', va='top', rotation=0,
            transform=axes.get_xaxis_transform())
axes.text(dr2['2638.HK'].std(), 0.89, "2638.HK std:{:#.4g}".format(dr2['2638.HK'].std()), color='b', ha='left', va='top', rotation=0,
            transform=axes.get_xaxis_transform())

dr1['0960.HK'].hist(bins = 100, label = '0960.HK', alpha = 0.5, align = 'mid')
axes.axvline(dr1['0960.HK'].median(), color='r', linestyle='dashed', linewidth=1)
axes.text(dr1['0960.HK'].median(), 0.79, "0960.HK median:{:#.4g}".format(dr1['0960.HK'].median()), color='r', ha='right', va='top', rotation=0,
            transform=axes.get_xaxis_transform())
axes.text(dr1['0960.HK'].std(), 0.69, "0960.HK std:{:#.4g}".format(dr1['0960.HK'].std()), color='r', ha='left', va='top', rotation=0,
            transform=axes.get_xaxis_transform())

axes.xaxis.set_ticks(np.arange(-0.25, 0.2501, 0.05))
plt.legend()
plt.show()






