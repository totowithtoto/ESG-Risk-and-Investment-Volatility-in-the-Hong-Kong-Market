
import pandas as pd
import numpy as np

dr = pd.read_csv("DailyReturn/Daily_Return.csv", index_col=0)
dr = dr.T

drupdate = dr.drop(["2007.HK", "3333.HK", "4332.HK", "4333.HK", "4335.HK", "4336.HK", "4337.HK", "4338.HK",], axis=1)
drupdate = drupdate.T
#drupdate.to_csv("Daily_Return_Update.csv")
#print(drupdate)

sector = pd.read_csv("Company information_update.csv", index_col=0)
sector = pd.DataFrame(sector["Sector"])
#print(sector)

drsec = pd.merge(sector, drupdate, on="Ticker", how="left" )
drsec = drsec.groupby("Sector").agg("std")
drsec = drsec.T
# print(drsec)
# Calculate the median for sorting
median_values = drsec.median()
median_values.columns = ['Sector', 'Median']
median_values = median_values.sort_values()
median_values = median_values.reset_index()
median_values['Median'] = median_values.iloc[:,1]
median_values = median_values [['Sector','Median']]
print(median_values.columns)

# Merge to get the sorted order
drsec = drsec.T
# drsec = drsec.sort_values(by = '0', )
drsec = drsec.reset_index()
drsec1 = pd.merge(median_values, drsec, on='Sector', how='left')
drsec1 = drsec1.drop(columns=['Median'])
drsec1 = drsec1.set_index(['Sector'])
drsec1 = drsec1.T
print(drsec1)

import seaborn as sns
import matplotlib.pyplot as plt

# Create the violin plot
plt.figure(figsize=(8, 6))
sns.violinplot(data=drsec1, palette="Blues_d")
plt.xlabel('Sector')
plt.xticks(rotation=30, horizontalalignment='right')
plt.ylabel('Daily Return Volatility')
plt.title('Daily Return Volatility by Sector')
plt.subplots_adjust(bottom=0.3)
plt.show()

