import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as stats
import seaborn as sns
import plotly.express as px
import statsmodels.api as sm
import warnings
pd.set_option('display.max_columns', 50, 'display.width', 200)

ESG = pd.read_csv('ESG_Data.csv',index_col=0)
CoInfo = pd.read_csv('Company information_update.csv', index_col=0)
# print(CoInfo)
# print(ESG)
df = pd.concat([ESG, CoInfo['Number of Employees']], axis=1).dropna()
# print(df)

x = df['Number of Employees']
y = df['ESG Risk Score']

x = sm.add_constant(x)
model = sm.OLS(y,x).fit()
print(model.params)


#print(model.summary())

m,c=np.polyfit(df['Number of Employees'], df['ESG Risk Score'],1)
plt.scatter(df['Number of Employees'],df['ESG Risk Score'], color='blue')
plt.plot(df['Number of Employees'],m * df['ESG Risk Score'] + c)
plt.text(1,90,
         'y=' + '{:.3f}'.format(m) + 'X' + '+{:.3f}'.format(c),
         size=12, color='r')
plt.xlabel('Number of Employees')
plt.ylabel('ESG Risk Score')
plt.title('Scatter plot of ESG Risk Score/ Number of Employees')
#plt.show()




"""
y = df['Number of Employees']
x = df['ESG Risk Score']

x = sm.add_constant(x)
model = sm.OLS(y,x).fit()
print(model.params)
print(model.summary())

m,c=np.polyfit(df['ESG Risk Score'], df['Number of Employees'],1)
plt.scatter(df['ESG Risk Score'],df['Number of Employees'], color='blue')
plt.plot(df['ESG Risk Score'],m * df['Number of Employees'] + c)
plt.text(1,90,
         'y=' + '{:.3f}'.format(m) + 'X' + '+{:.3f}'.format(c),
         size=12, color='r')
plt.xlabel('ESG Risk Score')
plt.ylabel('Number of Employees')
plt.title('Scatter plot of ESG Risk Score/ Number of Employees')
plt.show()
"""

def myPredition(x):
    y = m * x + c
    print('By the OLS model, we can predict that if the number of employee are ', x,
          'the ESG Risk Score will arrive to ', round(y,2))
print('\n====OLS Predition ==========\n')
myPredition(300000)