import pandas as pd
import plotly.express as px
import statsmodels.api as sm

pd.set_option('display.max_columns', None, 'display.width', 200,'display.max_rows',None)

# Data
x = pd.read_csv('Daily_Return_Update.csv', index_col="Ticker")
x["std"] = x.std(axis=1)
x = x["std"]
#print(x)

y = pd.read_csv('ESG_Data.csv', index_col="Ticker")
y = y[["Sector", "ESG Risk Score"]]
#print(y)

df = pd.concat([y, x], axis=1)
#print(df)
df1 = pd.DataFrame([])
df1 = df.groupby("Sector").agg("median")
df2 = pd.merge(df,df1,how = "left",on = 'Sector')
df2 = df2.sort_values("std_y", ascending=False) # sort value by decreasing sector std_median
df2 = df2.rename(columns={"ESG Risk Score_y":"ESG Risk Score_median", "std_y":"std_median"})
df2['normesg'] = (df2['ESG Risk Score_x']-min(df2['ESG Risk Score_x']))/ (max(df2['ESG Risk Score_x']-min(df2['ESG Risk Score_x'])))
df2['normstd'] = (df2['std_x']-min(df2['std_x']))/ (max(df2['std_x']-min(df2['std_x'])))
#print(df1)  ## 2 columns with sector totals
#print(df2)  ## 7 columns of tickers with median and normalised axis data, sorted by descending std median

##DataFrame for sectors with positive slope
possector = ["Basic Materials","Industrials", "Utilities",  "Energy"]
posslope = df1.T
posslope = posslope[["Basic Materials","Industrials", "Utilities", "Energy"]]
posslope = posslope.T
posslope = pd.merge(df,posslope,how = "inner",on = 'Sector')
posslope = posslope.sort_values("std_y", ascending=False) # sort value by decreasing sector std_median
posslope = posslope.rename(columns={"ESG Risk Score_x":"ESG"})
posslope['normesg'] = (posslope['ESG']-min(posslope['ESG']))/ (max(posslope['ESG']-min(posslope['ESG'])))
posslope['normstd'] = (posslope['std_x']-min(posslope['std_x']))/ (max(posslope['std_x']-min(posslope['std_x'])))
#print(posslope)

#Plotly express Plot by Sectors with Positive Slope

fig = px.scatter(posslope, x="normstd", y="normesg", color="Sector",
                 trendline="ols", title="ESG v. STD for Sectors with Positive slope")

# Update axis label font size
fig.update_layout(
    xaxis_title_font_size=18,  # Set x-axis label font size to 16
    yaxis_title_font_size=18   # Set y-axis label font size to 16
)

import statsmodels.formula.api as sm
# Fit the OLS model
model = sm.ols("normesg ~ normstd", data=posslope)
results = model.fit()
# Calculate R-squared and F-value
r_squared = results.rsquared
f_value = results.fvalue

# Add annotations
fig.add_annotation(
    x=0.8,  # Position on the x-axis (relative to plot width)
    y=0.1,  # Position on the y-axis (relative to plot height)
    xref="paper",  # Anchor to the plot paper
    yref="paper",  # Anchor to the plot paper
    text=f"R-squared: {r_squared:.3f}",  # Text of the annotation
    showarrow=False  # Remove arrow from annotation
)

fig.add_annotation(
    x=0.8,  # Position on the x-axis (relative to plot width)
    y=0.05,  # Position on the y-axis (relative to plot height)
    xref="paper",  # Anchor to the plot paper
    yref="paper",  # Anchor to the plot paper
    text=f"F-value: {f_value:.3f}",  # Text of the annotation
    showarrow=False  # Remove arrow from annotation
)

fig.show()



negslope = df1.T
negslope = negslope[["Communication Services","Consumer Defensive", "Technology"]]
negslope = negslope.T.reset_index()
negslope = pd.merge(df,negslope,how = "inner",on = 'Sector')
negslope = negslope.sort_values("std_y", ascending=False) # sort value by decreasing sector std_median
negslope = negslope.rename(columns={"ESG Risk Score_x":"ESG"})
negslope['normesg'] = (negslope['ESG']-min(negslope['ESG']))/ (max(negslope['ESG']-min(negslope['ESG'])))
negslope['normstd'] = (negslope['std_x']-min(negslope['std_x']))/ (max(negslope['std_x']-min(negslope['std_x'])))
#print(negslope)

#Plotly express Plot by Sectors with Negative Slope

fig = px.scatter(negslope, x="normstd", y="normesg", color="Sector",
                 trendline="ols", title="ESG v. STD for Sectors with Negative slope")

# Update axis label font size
fig.update_layout(
    xaxis_title_font_size=18,  # Set x-axis label font size to 16
    yaxis_title_font_size=18   # Set y-axis label font size to 16
)

import statsmodels.formula.api as sm
# Fit the OLS model
model = sm.ols("normesg ~ normstd", data=posslope)
results = model.fit()
# Calculate R-squared and F-value
r_squared = results.rsquared
f_value = results.fvalue

# Add annotations
fig.add_annotation(
    x=0.8,  # Position on the x-axis (relative to plot width)
    y=0.1,  # Position on the y-axis (relative to plot height)
    xref="paper",  # Anchor to the plot paper
    yref="paper",  # Anchor to the plot paper
    text=f"R-squared: {r_squared:.3f}",  # Text of the annotation
    showarrow=False  # Remove arrow from annotation
)

fig.add_annotation(
    x=0.8,  # Position on the x-axis (relative to plot width)
    y=0.05,  # Position on the y-axis (relative to plot height)
    xref="paper",  # Anchor to the plot paper
    yref="paper",  # Anchor to the plot paper
    text=f"F-value: {f_value:.3f}",  # Text of the annotation
    showarrow=False  # Remove arrow from annotation
)

fig.show()

zeroslope = df1.T
zeroslope = zeroslope[["Consumer Cyclical", "Healthcare", "Financial Services","Real Estate"]]
zeroslope = zeroslope.T.reset_index()
zeroslope = pd.merge(df,zeroslope,how = "inner",on = 'Sector')
zeroslope = zeroslope.sort_values("std_y", ascending=False) # sort value by decreasing sector std_median
zeroslope = zeroslope.rename(columns={"ESG Risk Score_x":"ESG"})
zeroslope['normesg'] = (zeroslope['ESG']-min(zeroslope['ESG']))/ (max(zeroslope['ESG']-min(zeroslope['ESG'])))
zeroslope['normstd'] = (zeroslope['std_x']-min(zeroslope['std_x']))/ (max(zeroslope['std_x']-min(zeroslope['std_x'])))
print(zeroslope)

#Plotly express Plot by Sectors with Zero Slope

fig = px.scatter(zeroslope, x="normstd", y="normesg", color="Sector",
                 trendline="ols", title="ESG v. STD for Sectors with Zero slope")

# Update axis label font size
fig.update_layout(
    xaxis_title_font_size=18,  # Set x-axis label font size to 16
    yaxis_title_font_size=18   # Set y-axis label font size to 16
)

import statsmodels.formula.api as sm
# Fit the OLS model
model = sm.ols("normesg ~ normstd", data=zeroslope)
results = model.fit()
# Calculate R-squared and F-value
r_squared = results.rsquared
f_value = results.fvalue

# Add annotations
fig.add_annotation(
    x=0.8,  # Position on the x-axis (relative to plot width)
    y=0.1,  # Position on the y-axis (relative to plot height)
    xref="paper",  # Anchor to the plot paper
    yref="paper",  # Anchor to the plot paper
    text=f"R-squared: {r_squared:.3f}",  # Text of the annotation
    showarrow=False  # Remove arrow from annotation
)

fig.add_annotation(
    x=0.8,  # Position on the x-axis (relative to plot width)
    y=0.05,  # Position on the y-axis (relative to plot height)
    xref="paper",  # Anchor to the plot paper
    yref="paper",  # Anchor to the plot paper
    text=f"F-value: {f_value:.3f}",  # Text of the annotation
    showarrow=False  # Remove arrow from annotation
)

fig.show()