import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt

pd.set_option('display.max_columns', None, 'display.width', 200,'display.max_rows', None)

# Data
x = pd.read_csv('Daily_Return_Update.csv', index_col=0)
x["std"] = x.std(axis=1)
x = x["std"]
#print(x)

y = pd.read_csv('ESG_Data.csv', index_col=0)
y = y[["Sector", "ESG Risk Score"]]
#print(y)

df = pd.concat([y, x], axis=1)
df1 = pd.DataFrame([])
df1 = df.groupby("Sector").agg("median")
df2 = pd.merge(df,df1,how = "left",on = 'Sector')
df2 = df2.sort_values("std_y", ascending=False) # sort value by decreasing sector std_median
df2 = df2.rename(columns={"ESG Risk Score_y":"ESG Risk Score_median", "std_y":"std_median"})
df2 = df2.set_index("Sector")
df2['normesg'] = (df2['ESG Risk Score_x']-min(df2['ESG Risk Score_x']))/ (max(df2['ESG Risk Score_x']-min(df2['ESG Risk Score_x'])))
df2['normstd'] = (df2['std_x']-min(df2['std_x']))/ (max(df2['std_x']-min(df2['std_x'])))
#print(df2)
#print(df1)

#sectorlist = df2["Sector"].unique().tolist()
sectorlist = ['Technology', 'Consumer Cyclical', 'Basic Materials', 'Healthcare', 'Communication Services', 'Industrials',
          'Energy', 'Consumer Defensive', 'Real Estate', 'Financial Services', 'Utilities']
#print(sectorlist)


for i in sectorlist:
    df3 = df2.loc[i,:]
    #print(df3)
    fig, ax = plt.subplots()

    #plt.figure(figsize=(8, 6))
    ax.scatter(x= df3["normstd"], y=df3["normesg"], color='blue')
    x = df3["normstd"]
    y = df3["normesg"]
    x = sm.add_constant(x)
    model = sm.OLS(y, x)
    results = model.fit()
    b, m = results.params
    ax.axline(xy1=(0, b), slope=m, label=f'{i}, $y = {m:.1f}x {b:+.1f}$')
    ax.set_xlim(0,1)        # Set the minimum and maximum values for the x-axis
    ax.set_ylim(0,1)        # Set the minimum and maximum values for the y-axis
    ax.legend()
    # Add labels and title
    ax.set_xlabel('STD volatility')
    ax.set_ylabel('ESG risk score')
    ax.set_title('ESG vs. STD Sector:')
    ax.grid()

    ax.text(0.05, 0.98, f"R-squared: {results.rsquared:2f}", transform=ax.transAxes, fontsize=10, va="top")
    ax.text(0.05, 0.94, f"Adj. R-squared: {results.rsquared_adj:2f}", transform=ax.transAxes, fontsize=10, va="top")
    ax.text(0.05, 0.90, f"F-statistic: {results.fvalue:2f}", transform=ax.transAxes, fontsize=10, va="top")
    plt.savefig(f"{i}.png")
    #plt.show()











