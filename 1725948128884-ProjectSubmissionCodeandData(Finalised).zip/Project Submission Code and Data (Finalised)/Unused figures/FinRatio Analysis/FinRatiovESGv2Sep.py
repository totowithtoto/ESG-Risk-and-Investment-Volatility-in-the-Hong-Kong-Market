import pandas as pd
import plotly.express as px
import matplotlib.pyplot as plt
pd.set_option('display.max_columns', None, 'display.width', 200,'display.max_rows',None)

fr = pd.read_csv("Training Data MultiLinearAnalysis All years All sectors.csv", index_col=0)
fr2023 = fr.iloc[:150]
#print(fr2023)

# fig = px.scatter(fr2023, x="Total ESG Risk Score", y="Debt to Capital", color="Sector", title="ESG vs. Financial Leverage by Sectors 2023", trendline="ols")
# # Update layout to increase font size
# fig.update_layout(
#     title_font=dict(size=30),  # Title font size
#     xaxis_title_font=dict(size=24),  # X-axis label font size
#     yaxis_title_font=dict(size=24)   # Y-axis label font size
# )
# fig.update_layout(
#     legend=dict(
#         title='Legend Title',
#         title_font=dict(size=24),  # Legend title font size
#         font=dict(size=20)          # Legend item font size
#     )
# )
# # Update layout to increase margins
# fig.update_layout(
#     margin=dict(l=150, b=150, t=150)  # Increase left (l) and bottom (b) margins
# )
#
# fig.show()

fig = px.scatter(fr2023, x="Total ESG Risk Score", y="Return on Invested Capital", color="Sector", title="ESG vs. Return on Invested Capital by Sectors 2023", trendline="ols")
# Update layout to increase font size
fig.update_layout(
    title_font=dict(size=30),  # Title font size
    xaxis_title_font=dict(size=24),  # X-axis label font size
    yaxis_title_font=dict(size=24)   # Y-axis label font size
)
fig.update_layout(
    legend=dict(
        title='Legend Title',
        title_font=dict(size=24),  # Legend title font size
        font=dict(size=20)          # Legend item font size
    )
)
# Update layout to increase margins
fig.update_layout(
    margin=dict(l=150, b=150, t=150)  # Increase left (l) and bottom (b) margins
)
fig.show()

fig = px.scatter(fr2023,x="Total ESG Risk Score",y="Number of Employees", color="Sector", title="ESG vs. Number of Employees", trendline="ols")
# Update layout to increase font size
fig.update_layout(
    title_font=dict(size=30),  # Title font size
    xaxis_title_font=dict(size=24),  # X-axis label font size
    yaxis_title_font=dict(size=24)   # Y-axis label font size
)
fig.update_layout(
    legend=dict(
        title='Legend Title',
        title_font=dict(size=24),  # Legend title font size
        font=dict(size=20)          # Legend item font size
    )
)
# Update layout to increase margins
fig.update_layout(
    margin=dict(l=150, b=150, t=150)  # Increase left (l) and bottom (b) margins
)
fig.show()














