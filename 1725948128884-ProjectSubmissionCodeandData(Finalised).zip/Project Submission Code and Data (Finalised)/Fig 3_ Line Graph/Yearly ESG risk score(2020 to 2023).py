import pandas as pd
import numpy as np

pd.set_option('display.max_columns', None, 'display.width', 200, 'display.max_rows', None)

myPath = "ESGhisdata\\"
years = np.arange(2020,2024)
print(years)
dataframes = []
dataframes = pd.DataFrame(dataframes)
dataframes1 = []
dataframes1 = pd.DataFrame(dataframes1)

for year in years:
    esg = pd.read_csv(myPath + f'ESG_Data{year}.csv', index_col=0)
    esg1 = pd.read_csv(myPath + f'ESG_Data{year}.csv', index_col=0)
    esg = esg.drop(columns=["G Score", "E Score", "S Score"],axis=1)
    esg1 = esg1.drop(columns=["ESG Risk Score"],axis=1)
    esg1.drop(esg1[esg1["G Score"] == 0].index, inplace=True)
    print(esg)
    print(esg1)
    esg = esg.mean()
    esg1 = esg1.mean()
    print(esg)
    esg = pd.DataFrame(esg)
    esg1 = pd.DataFrame(esg1)
    esg = esg.T
    esg1 = esg1.T
    esg["Year"] = year
    esg1["Year"] = year
    esg = esg.set_index("Year")
    esg1 = esg1.set_index("Year")
    print(esg)
    print(esg1)
    dataframes = pd.concat([dataframes, esg], ignore_index=False)
    dataframes1 = pd.concat([dataframes1, esg1], ignore_index=False)


print(dataframes)
print(dataframes1)

dataframes = dataframes.merge(dataframes1, how="left", on="Year")
print(dataframes)
dataframes.to_csv(myPath + "Average Score of yearly ESG Data.csv", sep=',')

import matplotlib.pyplot as plt
import seaborn as sns

esg_risk = dataframes.drop(columns=["G Score", "E Score", "S Score"],axis=1)
esg_risk = esg_risk.reset_index()
esg_risk = pd.melt(esg_risk, ["Year"])

risk = dataframes.drop(columns=["ESG Risk Score"], axis=1)
risk = risk.reset_index()
risk = pd.melt(risk, ["Year"])

fig, ax1 = plt.subplots()
sns.set(style="ticks")

sns.lineplot(data=esg_risk, x='Year', y='value', label="ESG Risk Score",marker='o', markersize=8, ax=ax1, color="red")

ax2 = ax1.twinx()

sns.lineplot(data=risk, x='Year', y='value', hue='variable', linestyle='dashed', marker='o', markersize=5, ax=ax2)
ax1.set_xticks(esg_risk["Year"], esg_risk["Year"])
ax1.set_xlabel("Year")
ax1.set_ylabel("ESG Risk Score")
ax2.set_ylabel("Risk Score")
ax2.set_title("Yearly ESG risk score(2020 to 2023)")
ax2.legend([ax1.get_lines()[0], ax2.get_lines()[0], ax2.get_lines()[1], ax2.get_lines()[2]],
    ["ESG Risk Score","G Score", "E Score", "S Score"], loc="upper right")

plt.show()
