import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
pd.set_option('display.max_columns', 50, 'display.width', 200)
year = np.arange(2020,2024)

for y in year:
    df = pd.read_csv(f"Spearman's correlation coefficient Industry to ESG risk Score{y}.csv",index_col=0)
    count = np.array(df["count"])
    print(count)
    df = df.T
    df = df.rename(columns={"Basic Materials":f"Basic Materials({count[0]})",
                            "Communication Services":f"Communication Services({count[1]})",
                            "Consumer Defensive":f"Consumer Defensive({count[3]})",
                            "Energy":f"Energy({count[4]})",
                            "Financial Services":f"Financial Services({count[5]})",
                            "Healthcare":f"Healthcare({count[-6]})",
                            "Industrials":f"Industrials({count[-5]})",
                            "Real Estate":f"Real Estate({count[-4]})",
                            "Technology":f"Technology({count[-3]})",
                            "Utilities":f"Utilities({count[-2]})",
                            "Total":f"Total({count[-1]})",
                            })
    df = df.rename(columns={"Consumer Cyclical":f"Consumer Cyclical({count[2]})"})
    df = df.T
    # print(df)
# Sort the DataFrame by 'Pearman's correlation coefficient' in descending order
    df = df.sort_values(by='Pearson\'s correlation coefficient', ascending=False)
    print(df)

# # Create the figure and subplots
    fig, axes = plt.subplots(1, 2, figsize=(12, 6), sharey=True) #Added share y axis
#
# First subplot: Correlation coefficients
    sns.heatmap(df[['Spearman\'s correlation coefficient', 'Pearson\'s correlation coefficient']],
                annot=True, fmt=".2f", cmap="RdYlGn", ax=axes[0])
    axes[0].set_title(f'Correlation Coefficients\n({y})')
    axes[0].set_xticklabels(axes[0].get_xticklabels(), rotation=25, ha="right", rotation_mode="anchor")

# Second subplot: P-values (with white for values over 0.25)
# Create a custom colormap with white for values over 0.25
    cmap = sns.color_palette("Greens", as_cmap=True)
    cmap = cmap.reversed()  # Reverse the colormap
    cmap.set_bad("white")  # Set values over 0.25 to white

    sns.heatmap(df[['Spearman\'s P-value', 'Pearson\'s P-value']],
            annot=True, fmt=".2f", cmap=cmap, vmin=0, vmax=0.25, ax=axes[1])
    axes[1].set_title(f'P-values\n({y})')
    axes[1].set_xticklabels(axes[1].get_xticklabels(), rotation=25, ha="right", rotation_mode="anchor")

# Adjust layout and show the plot
    plt.tight_layout()
    plt.show()

